# PAC 2 Visualització de dades
Repositori amb visualitzacions de les tècniques assignades a la PAC2.
